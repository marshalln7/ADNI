#LONI - Freeze 2
#Alaina Durant - 10 2023

#directory
directory <- "C:/Users/durantam/VUMC/Research - Hohman - CNT/"
my_directory <- paste0(directory, "Team/Alaina_Durant/")
vrf_directory <- paste0(directory, "Projects/ADSP-PHC/Freeze 2/Harmonization/Cardiovascular_Risk/")

#library and functions
source(paste0(my_directory, "Scripts/load_libraries.R"))
source(paste0(my_directory, "Scripts/load_functions.R"))
#function count(df$ID) works as length(unique(df$ID))


####################
##### ADSP IDs #####
####################

ADSP <- readRDS(paste0(directory, "Data/ADSP/2023/GCAD_Pre-r5_2023_IDLink.rds")) %>% 
  dplyr::filter(cohort == "ADNI") #obs/inds:1566


###############################
##### ADNI Cognitive Data #####
###############################

ADNI <- read.csv(paste0(vrf_directory, "ADNI/Cleaned/ADNI_PHC_VascularRisk_CleanedNov2023.csv")) #obs/inds:1577, cols:20


#############
### Merge ###
#############

#keep everyone with or without SUBJID
ADNI_ADSP <- merge(ADNI, ADSP, by.x = "PTID", by.y = "original_ID", all.x = T) #obs/inds:1577, cols:22

#clean up
rm(ADNI, ADSP)


#############################
### Keep, Rename, Reorder ###
#############################

#Keep relevant variables
ADNI_ADSP <- ADNI_ADSP %>% dplyr::select(RID, SUBJID, Phase, VISCODE, VISCODE2, EXAMDATE, PHC_Visit, Sex, Education, Ethnicity,
                                         Race, Age, Diagnosis, PHC_Hypertension, PHC_Diabetes, PHC_Heart, PHC_BMI, PHC_CVRScore) #obs:12533, cols:25, inds:3539

#Rename variables
ADNI_ADSP <- ADNI_ADSP %>% dplyr::rename(PHASE=Phase, PHC_Sex=Sex, PHC_Education=Education, PHC_Ethnicity=Ethnicity, 
                                         PHC_Race=Race, PHC_Age_CardiovascularRisk=Age, PHC_Diagnosis=Diagnosis)

#order variables
ADNI_ADSP <- ADNI_ADSP[order(ADNI_ADSP$RID, ADNI_ADSP$PHC_Visit),]


#######################
##### Save as csv #####
#######################

write.csv(ADNI_ADSP, paste0(directory, "Projects/ADSP-PHC/Freeze 2/LONI_Release_Oct2023/Cardiovascular_Risk/ADSP_PHC_VRF_Nov2023.csv"), row.names = F)
